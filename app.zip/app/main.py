import os
import json
from datetime import datetime
from utils import extract_text_from_pdfs, rank_sections

# Simulated persona + job-to-be-done (you will load these dynamically)
persona = "Investment Analyst"
job = "Compare R&D spending and strategies"

input_dir = "./app/input"
output_dir = "./app/output"

# Step 1: Extract text with metadata from each PDF
documents_data = extract_text_from_pdfs(input_dir)

# Step 2: Rank relevant sections
ranked_sections, subsection_analysis = rank_sections(documents_data, persona, job)

# Step 3: Build output JSON
output_json = {
    "metadata": {
        "documents": list(documents_data.keys()),
        "persona": persona,
        "job_to_be_done": job,
        "timestamp": datetime.now().isoformat()
    },
    "extracted_sections": ranked_sections,
    "subsection_analysis": subsection_analysis
}

# Step 4: Save
with open(os.path.join(output_dir, "output.json"), "w") as f:
    json.dump(output_json, f, indent=2)
