import os
import fitz  # PyMuPDF
from sentence_transformers import SentenceTransformer, util

model = SentenceTransformer("all-MiniLM-L6-v2")

def extract_text_from_pdfs(folder_path):
    pdf_data = {}
    for filename in os.listdir(folder_path):
        if filename.endswith(".pdf"):
            doc = fitz.open(os.path.join(folder_path, filename))
            pages = []
            for i, page in enumerate(doc):
                text = page.get_text()
                if text.strip():
                    pages.append((i+1, text))
            pdf_data[filename] = pages
    return pdf_data

def rank_sections(pdf_data, persona, job):
    query = f"{persona} needs to: {job}"
    query_embedding = model.encode(query, convert_to_tensor=True)

    sections = []
    subsection_analysis = []

    for doc_name, pages in pdf_data.items():
        for page_num, text in pages:
            score = util.pytorch_cos_sim(model.encode(text, convert_to_tensor=True), query_embedding).item()
            sections.append({
                "document": doc_name,
                "page": page_num,
                "section_title": text.split('\n')[0][:80],
                "importance_rank": round(score, 3)
            })
            subsection_analysis.append({
                "document": doc_name,
                "page": page_num,
                "refined_text": text[:500],
                "importance_rank": round(score, 3)
            })

    # Sort by relevance
    sections.sort(key=lambda x: x["importance_rank"], reverse=True)
    subsection_analysis.sort(key=lambda x: x["importance_rank"], reverse=True)

    return sections[:5], subsection_analysis[:5]  # Return top 5
